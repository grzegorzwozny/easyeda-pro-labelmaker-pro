# Label Maker Pro (EasyEDA Pro Extension)

This project is an EasyEDA Pro extension that creates shaped PCB silkscreen labels with cutout text.

## Features

- Silkscreen label generation on `TOP_SILKSCREEN` and `BOTTOM_SILKSCREEN`
- Left/right label cap styles (`(`, `)`, `<`, `>`, `/`, `\`, `|`, `[`, `]`)
- Font, size, padding, fixed width and text alignment controls
- Live preview
- Presets stored via extension storage

## Build

```bash
npm install
npm run build
```

The installable package is generated under:

- `build/dist/eext-labelmaker-pro_v1.0.0.eext`

## Install in EasyEDA Pro

1. Open EasyEDA Pro.
2. Open Extension Manager.
3. Install from local file and select the generated `.eext` package.

## Notes

- Place labels from PCB editor.
- Label position is centered at current mouse position.
- All dimensions in the UI are `mil`.
