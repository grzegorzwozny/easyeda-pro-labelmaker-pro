# Label Maker Pro

EasyEDA Pro extension for creating shaped silkscreen labels with cutout text.

- Menu: `PCB -> Label Maker -> Open Label Maker...`
- Output: silkscreen fill primitives (top or bottom silkscreen)
- Package format: `.eext`

## Build

```bash
npm install
npm run build
```

The generated extension package is in `build/dist/`.
